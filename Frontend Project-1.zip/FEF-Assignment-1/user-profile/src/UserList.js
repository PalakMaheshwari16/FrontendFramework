import React from 'react';
import UserProfile from './UserProfile';

const UserList = ({ users }) => {
    return (
        <div className="UserList">
            {users.length === 0 ? (
                <p className="no-users-message">No users available</p>
            ) : (
                users.map(user => <UserProfile key={user.id} user={user} />)
            )}
        </div>
    );
};

export default UserList;
