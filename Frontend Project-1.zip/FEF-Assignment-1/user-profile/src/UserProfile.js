import React from 'react';

const UserProfile = ({ user }) => {
    return (
        <div className="UserProfile">
            <h3>{user.name}</h3>
            <p>Age: {user.age}</p>
            <p>Occupation: {user.occupation}</p>
        </div>
    );
};

export default UserProfile;
