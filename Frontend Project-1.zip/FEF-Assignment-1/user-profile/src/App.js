import React, { useState } from 'react';
import AddUserForm from './AddUserForm';
import UserList from './UserList';
import './App.css';

const App = () => {
    const [users, setUsers] = useState([]);

    const addUser = (user) => {
        setUsers([...users, user]);
    };

    return (
        <div>
            <h1>User Profiles</h1>
            <AddUserForm addUser={addUser} />
            <UserList users={users} />
        </div>
    );
};

export default App;