import React, { useState } from 'react';
import PropTypes from 'prop-types';
import UpdateProductForm from './UpdateProductForm';

const Product = () => {
    const [product, setProduct] = useState(null);

    const updateProductDetails = (updatedProduct) => {
        setProduct(updatedProduct);
    };

    return (
        <div className="product">
            {product ? (
                <>
                    <h2>{product.name}</h2>
                    <p>Price: Rs. {product.price}</p>
                    <p>Description: {product.description}</p>
                </>
            ) : (
                <p>No product details available</p>
            )}
            <UpdateProductForm updateProduct={updateProductDetails} />
        </div>
    );
};

export default Product;
