import React, { useState } from 'react';
import PropTypes from 'prop-types';

const UpdateProductForm = ({ updateProduct }) => {
    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [description, setDescription] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        updateProduct({ name, price: parseFloat(price), description });
    };

    return (
        <form onSubmit={handleSubmit} className="update-product-form">
            <input 
                type="text" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                placeholder="Product Name" 
                required
            />
            <input 
                type="number" 
                value={price} 
                onChange={(e) => setPrice(e.target.value)} 
                placeholder="Price" 
                required
            />
            <textarea 
                value={description} 
                onChange={(e) => setDescription(e.target.value)} 
                placeholder="Description" 
                required
            />
            <button type="submit">Update Product</button>
        </form>
    );
};

UpdateProductForm.propTypes = {
    updateProduct: PropTypes.func.isRequired,
};

export default UpdateProductForm;
