import React from 'react';
import Product from './Product';
import './App.css'

const App = () => {
    return (
        <div className="App">
            <h1>Product Information</h1>
            <Product />
        </div>
    );
};

export default App;
